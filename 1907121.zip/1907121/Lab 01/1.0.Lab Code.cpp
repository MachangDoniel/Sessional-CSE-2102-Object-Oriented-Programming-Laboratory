#include<bits/stdc++.h>
using namespace std;

int main()
{
    float num;
    double num2;
    cin>>num;
    num2=num;
    cout<<std::setprecision(7)<<num<<endl;
    cout<<num2<<endl;
    cout<<"Hello World"<<endl;
}
