//Inline function

#include<bits/stdc++.h>
using namespace std;

inline int mul(int a,int b)
{
    return a*b;
}

int main()
{
    cout<<mul(5,6)<<endl;
    cout<<mul(7,6)<<endl;
    cout<<mul(9,6)<<endl;
    cout<<mul(15,6)<<endl;
}
