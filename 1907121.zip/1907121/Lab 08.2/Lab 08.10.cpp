//Standard Template Library
//Substring

#include<bits/stdc++.h>
#include<iostream>
#include<string>

using namespace std;

int main()
{
    string s="hello girls";
    string s1=s.substr(0,5);
    cout<<s1<<endl;
}
